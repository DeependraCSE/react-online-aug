import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <div>
                    <h2>Child Component</h2>
                    <h3>Title : { this.props.title || "Default Title" }</h3>
                    <h4>Version : { this.props.version || "000" } | Start Time { this.props.time || "0.00" }</h4>
                    <hr />
                    { this.props.children }
               </div>
    }
}

export default ChildComp;