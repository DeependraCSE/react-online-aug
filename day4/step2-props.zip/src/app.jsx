import { Component } from 'react';
import ChildComp from './child';

class App extends Component{
    render(){
        return  <div>
                    <h1>Props in React</h1>
                    <ChildComp time={"1:pm"} version={1001} title="Avenger">
                        <button>Click Me</button>
                    </ChildComp>
                    <ChildComp version={1002} title="Justice League">
                        <ol>
                            <li>List Item 1</li>
                            <li>List Item 2</li>
                            <li>List Item 3</li>
                        </ol>
                    </ChildComp>
                    <ChildComp time={"3:pm"} version={1003} title="Indic Hereoes">
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illum impedit, eos recusandae possimus laboriosam ea ullam quasi iusto exercitationem, eligendi accusantium deleniti earum laborum, delectus magnam dolorem sequi quia eveniet?
                        </p>
                    </ChildComp>
                    <ChildComp>
                        <button>Click Me</button>
                        <ul>
                            <li>List Item 1</li>
                            <li>List Item 2</li>
                            <li>List Item 3</li>
                        </ul>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illum impedit, eos recusandae possimus laboriosam ea ullam quasi iusto exercitationem, eligendi accusantium deleniti earum laborum, delectus magnam dolorem sequi quia eveniet?
                        </p>
                    </ChildComp>
                </div>
    }
}

export default App;