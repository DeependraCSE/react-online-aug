import { Component } from "react";

class ClassApp extends Component{
    render(){
        return <div>
                <h1>Hello from Class Component</h1>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
               </div>
    }
}

export default ClassApp;