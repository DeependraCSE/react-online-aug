let FunApp = function(){
    return <h1>Hello from Function Component</h1>
} 

export default FunApp;