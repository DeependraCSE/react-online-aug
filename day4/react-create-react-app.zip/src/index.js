import ReactDOM from "react-dom/client";
// import ClassApp from "./app";
import FunApp from "./funapp";

/* 
ReactDOM
.createRoot(document.getElementById("root"))
.render(React.createElement("h1",null,"welcome to your life")) 
*/

ReactDOM
.createRoot(document.getElementById("root"))
.render(<FunApp/>)
