import { Component } from 'react';

/* 
or here
*/
let user = "Vijay";

class App extends Component{
    // public
    total = 5 + 6;
    show = true;
    localuser = "Guest";
    /* 
    here....
    */
    render(){
        return <> {/* <> is alias for React.Fragment */}
                <div>
                    <h1>JSX in React { 5 + 6 } </h1>
                    <h1>Total is { this.total } </h1>
                    <h2>Show is { this.show ? "True" : "False" } </h2>
                    <h3>User is { user }</h3>
                    <h3>Local user is { this.localuser }</h3>
                </div>
                <div>
                    <img src="" alt="" />
                    <hr/>
                    <br/>
                    <input type="text" />
                </div>
                <section className="box">
                    i am a section tag
                </section>
                <label htmlFor="same">Select me</label>
                <input id='same' type="checkbox" />
                <br/>
                <input type="text" defaultValue="enter your name here" />
                <h1 style={ { color : 'darkorange', backgroundColor : 'papayawhip' } }>Style Me</h1>
                <h1></h1>
                <button onClick={() => alert("you clicked the button")}>Click Me</button>
               </>
    }
}

class H1 extends Component{
    render(){
        return <h1>I am a default h1 tag</h1>
    }
}


export default App;
export {H1};