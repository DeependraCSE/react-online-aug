import { createRoot } from 'react-dom/client';
import App, { H1 } from './app';

createRoot(document.getElementById('root'))
.render(<> <App/> <H1/> </>)
