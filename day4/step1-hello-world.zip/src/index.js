import React, { Component } from "react";
import ReactDOM from "react-dom/client";

// class component
/* 
*/
class ClassApp extends Component{
    render(){
        return <div>
                <h1>Hello from Class Component</h1>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
                <p> content for paragraph comes here </p>
               </div>
    }
} 

// function component
let FunApp = function(){
    return <h1>Hello from Function Component</h1>
} 

/* 
ReactDOM
.createRoot(document.getElementById("root"))
.render(React.createElement("h1",null,"welcome to your life")) 
*/

ReactDOM
.createRoot(document.getElementById("root"))
.render(<ClassApp/>)

// ReactDOM : select the root element 
// React Component : render the element / component 