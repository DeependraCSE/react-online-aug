import axios from "axios";
import { useEffect, useRef, useState } from "react";

let App = () => {
  
  let [users, setUsers] = useState([]);
  let selectRef = useRef();
  /* 
  useEffect(function(){
    // console.log("App is mounted")
    axios.get(url).then(res => {
      setUsers(res.data.data);
    }).catch(err => {
      console.log("Error ", err)
    })
  },[]) 
  */
  let clickHandler = () => {
    let selectedlist = selectRef.current.value;
    console.log(selectedlist);
    if(selectedlist === "Defult"){
      alert("select from the list first");
    }else{
      let url = "https://reqres.in/api/users?page="+selectRef.current.value;
      axios.get(url).then(res => {
        setUsers(res.data.data);
      }).catch(err => {
        console.log("Error ", err)
      })
    }
  }
  return <div className="container">
            <h1 className="display-1 bg-secondary">HTTP using useEffect hook</h1>
            <select ref={selectRef} >
              <option>Defult</option>
              <option defaultValue={1}>1</option>
              <option defaultValue={2}>2</option>
            </select>
            <button onClick={clickHandler} className="btn btn-primary">Get Users Data</button>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Sl #</th>
                  <th>eMail</th>
                  <th>Full Name</th>
                  <th>Photo</th>
                </tr>
              </thead>
              <tbody>
                {users.map((val) => <tr key={val.id}>
                  <td>{ val.id }</td>
                  <td>{ val.email }</td>
                  <td>{ val.first_name+" "+val.last_name }</td>
                  <td>
                    <img width={80} src={val.avatar} alt={ val.first_name+" "+val.last_name } />
                  </td>
                </tr>)}
              </tbody>
            </table>
          </div>
};

export default App;
