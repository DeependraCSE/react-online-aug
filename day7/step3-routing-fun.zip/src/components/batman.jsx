import { useParams } from "react-router-dom";

let BatmanComp = () => {
  let totalOrder = useParams();
    return <div style={ {border : "2px solid grey", height : "700px"} }>
              <h2 className="display-5 bg-info">Batman Component</h2>
              <h3>Order Quantity Requested : {totalOrder.qty} </h3>
            </div>
  };
  
  export default BatmanComp;