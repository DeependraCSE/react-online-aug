let WonderWomenComp = () => {
    return <div style={ {border : "2px solid grey", height : "700px"} }>
              <h2 className="display-5 bg-info">WonderWomen Component</h2>
            </div>
  };
  
  export default WonderWomenComp;