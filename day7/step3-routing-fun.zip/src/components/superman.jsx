let SupermanComp = () => {
    return <div style={ {border : "2px solid grey", height : "700px"} }>
              <h2 className="display-5 bg-info">Superman Component</h2>
            </div>
  };
  
  export default SupermanComp;