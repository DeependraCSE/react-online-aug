let AquamanComp = () => {
    return <div style={ {border : "2px solid grey", height : "700px"} }>
              <h2 className="display-5 bg-info">Aquaman Component</h2>
            </div>
  };
  
  export default AquamanComp;