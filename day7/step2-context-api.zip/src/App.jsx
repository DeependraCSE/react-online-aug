import GrandComp from "./grandparent";

let App = () => {
  return <div className="container">
            <h1 className="display-1 bg-secondary">Using Context API</h1>
            <GrandComp/>
          </div>
};

export default App;