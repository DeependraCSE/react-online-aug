import { useContext } from "react";
import FamilyContext from "./contexts/familycontext";


let CousinComp = () => {
    let value = useContext(FamilyContext);
    return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Cousin Component</h2>
                    <h3>Cousin Info is { value }</h3>
                </div>
           </div>
  };
  
  export default CousinComp;
  