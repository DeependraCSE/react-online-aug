/* 
import { useRef, useState } from "react";
import ParentComp from "./parent";

let GrandComp = () => {
    let [info, setInfo] = useState("default info message");
    let ipRef = useRef();
    return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Grand Parent Component</h2>
                    <input ref={ipRef} type="text" />
                    <button onClick={() => setInfo(ipRef.current.value)}>Send Message</button>
                    <ParentComp info={info}/>
                </div>
           </div>
  };
  
  export default GrandComp; 
*/
  
import { useRef, useState } from "react";
import ParentComp from "./parent";
import FamilyContext from "./contexts/familycontext";
import CousinComp from "./cousin";

let GrandComp = () => {
    let [info, setInfo] = useState("default info message");
    let ipRef = useRef();
    return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Grand Parent Component</h2>
                    <input ref={ipRef} type="text" />
                    <button onClick={() => setInfo(ipRef.current.value)}>Send Message</button>
                    <FamilyContext.Provider value={info}>
                        <ParentComp />
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
           </div>
  };
  
  export default GrandComp;
  