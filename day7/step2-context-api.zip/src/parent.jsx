/* 
import ChildComp from "./child";

let ParentComp = (props) => {
    return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Parent Component</h2>
                    <ChildComp info={props.info}/>
                </div>
           </div>
  };
  
 export default ParentComp; 
*/
  
import ChildComp from "./child";

let ParentComp = () => {
    return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Parent Component</h2>
                    <ChildComp/>
                </div>
           </div>
  };
  
  export default ParentComp;
  