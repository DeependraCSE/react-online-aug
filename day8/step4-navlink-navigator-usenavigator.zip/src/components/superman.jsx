import { useParams } from "react-router-dom";

let SupermanComp = () => {
    let args = useParams();
    return <div style={ {border : "2px solid grey", height : "500px"} }>
              <h2 className="display-5 bg-info">Superman Component</h2>
              <h3 className="bg-info">Power is : { args.power || 0 }</h3>

            </div>
  };
  
  export default SupermanComp;