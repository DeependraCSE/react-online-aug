import { useState } from "react";
import { Navigate } from "react-router-dom";

let AquamanComp = () => {
    let [showwonderwomen, setWonderWomen] = useState(false)
    return <div style={ {border : "2px solid grey", height : "500px"} }>
              <h2 className="display-5 bg-info">Aquaman Component</h2>
              <button onClick={() => setWonderWomen(true)}>Navigate to Wonder Women</button>
             { showwonderwomen ? <Navigate to={"/wonderwomen"} replace={true} /> : " is false "} 
            </div>
  };
  
  export default AquamanComp;