let NotFoundComp = () => {
    return <div style={ {border : "2px solid grey", height : "500px"} }>
              <h2 className="display-5 bg-info">404 : Requested Page Not Found</h2>
            </div>
  };
  
  export default NotFoundComp;