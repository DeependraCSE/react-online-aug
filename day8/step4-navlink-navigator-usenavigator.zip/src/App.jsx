import {BrowserRouter, Routes, Route, Link, NavLink} from "react-router-dom"
import AquamanComp from "./components/aquaman";
import BatmanComp from "./components/batman";
import HomeComp from "./components/home";
import NotFoundComp from "./components/notfound";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen";
import { useState } from "react";
import "./mystyle.css";

let App = () => {
  let [quantity, setQuantity] = useState(0);
  let showActive = ({isActive}) =>   isActive ? 'nav-link boxer' : 'nav-link'; 
  return <div className="container">
            <h1 className="display-1 bg-secondary">Using Routes</h1>
            <input type="range" value={quantity} onInput={(evt) => setQuantity(Number(evt.target.value))}/>
            <h5>Quantity is : { quantity }</h5>
            <BrowserRouter>
              {/* Static Routes */}
              {/* 
              <ul className="nav">
                <li className="nav-item"> <Link className="nav-link" to="/">Home</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to={'/batman/'+quantity+"/vijay"}>Batman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/aquaman">Aquaman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/wonderwomen">Wonder Women</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/cyborg">Cyborg</Link> </li>
              </ul> 
              */}
              <ul className="nav">
                <li className="nav-item"> <NavLink className={ showActive } to="/">Home</NavLink> </li>
                <li className="nav-item"> <NavLink className={ showActive } to={'/batman/'+quantity+"/vijay"}>Batman</NavLink> </li>
                <li className="nav-item"> <NavLink className={ showActive } to="/superman">Superman</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/aquaman">Aquaman</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/wonderwomen">Wonder Women</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/flash">Flash</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/cyborg">Cyborg</NavLink> </li>
              </ul> 
              <Routes>
                <Route path="/" element={<HomeComp/>} /> {/* default route */}
                <Route path="/batman/:qty/:another" element={<BatmanComp/>} /> {/* named route */}
                <Route path="/superman" element={<SupermanComp/>} /> {/* named route */}
                <Route path="/superman/:power" element={<SupermanComp/>} /> {/* named route */}
                <Route path="/aquaman" element={<AquamanComp/>} /> {/* named route */}
                <Route path="/wonderwomen" element={<WonderWomenComp/>} /> {/* named route */}
                <Route path="*" element={<NotFoundComp/>} /> {/* wildcard route */}
              </Routes>
          </BrowserRouter>
          </div>
};

export default App;

/* 
npm i react-router-dom


*/