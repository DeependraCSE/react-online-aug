import {BrowserRouter, Routes, Route, Link, NavLink} from "react-router-dom";
import React from "react";
import HomeComp from "./components/home";
/* 
import AquamanComp from "./components/aquaman";
import BatmanComp from "./components/batman";
import NotFoundComp from "./components/notfound";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen"; 
*/
import { useState } from "react";
import "./mystyle.css";
import { Suspense } from "react";

let App = () => {
  let [quantity, setQuantity] = useState(0);
  let showActive = ({isActive}) =>   isActive ? 'nav-link boxer' : 'nav-link'; 
  /* these will be loaded on demand */
  let AquamanLazyComp = React.lazy( ()=> import("./components/aquaman") );
  let BatmanLazyComp = React.lazy( ()=> import("./components/batman") );
  let NotFoundLazyComp = React.lazy( ()=> import("./components/notfound") );
  let SupermanLazyComp = React.lazy( ()=> import("./components/superman") );
  let WonderWomenLazyComp = React.lazy( ()=> import("./components/wonderwomen") );
  return <div className="container">
            <h1 className="display-1 bg-secondary">Using Routes</h1>
            <input type="range" value={quantity} onInput={(evt) => setQuantity(Number(evt.target.value))}/>
            <h5>Quantity is : { quantity }</h5>
            <BrowserRouter>
              {/* Static Routes */}
              {/* 
              <ul className="nav">
                <li className="nav-item"> <Link className="nav-link" to="/">Home</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to={'/batman/'+quantity+"/vijay"}>Batman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/aquaman">Aquaman</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/wonderwomen">Wonder Women</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link> </li>
                <li className="nav-item"> <Link className="nav-link" to="/cyborg">Cyborg</Link> </li>
              </ul> 
              */}
              <ul className="nav">
                <li className="nav-item"> <NavLink className={ showActive } to="/">Home</NavLink> </li>
                <li className="nav-item"> <NavLink className={ showActive } to={'/batman/'+quantity+"/vijay"}>Batman</NavLink> </li>
                <li className="nav-item"> <NavLink className={ showActive } to="/superman">Superman</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/aquaman">Aquaman</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/wonderwomen">Wonder Women</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/flash">Flash</NavLink> </li>
                <li className="nav-item"> <NavLink className={({isActive}) => isActive ? 'nav-link boxer' : 'nav-link' } to="/cyborg">Cyborg</NavLink> </li>
              </ul> 
              <Routes>
                <Route path="/" element={ <HomeComp/> } />
                <Route path="/batman/:qty/:another" element={ <Suspense fallback={<>Loading...</>}> <BatmanLazyComp/></Suspense> } /> 
                <Route path="/superman" element={  <Suspense fallback={<>Loading...</>}> <SupermanLazyComp/></Suspense>} /> 
                <Route path="/superman/:power" element={ <Suspense fallback={<>Loading...</>}> <SupermanLazyComp/></Suspense> } /> 
                <Route path="/aquaman" element={  <Suspense fallback={<>Loading...</>}> <AquamanLazyComp/></Suspense>} /> 
                <Route path="/wonderwomen" element={ <Suspense fallback={<>Loading...</>}> <WonderWomenLazyComp/></Suspense> } /> 
                <Route path="*" element={ <Suspense fallback={<>Loading...</>}> <NotFoundLazyComp/></Suspense> } /> 
              </Routes>
          </BrowserRouter>
          </div>
};

export default App;