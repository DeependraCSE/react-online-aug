import { useParams, useNavigate } from "react-router-dom";
/* 
  query parameters
*/
let BatmanComp = () => {
  let args = useParams();
  let nav = useNavigate();
    return <div style={ {border : "2px solid grey", height : "500px"} }>
              <h2 className="display-5 bg-info">Batman Component</h2>
              <h3>Order Quantity Requested : {args.qty} </h3>
              <h3>User Name : {args.another} </h3>
              <button onClick={() => nav("/superman/"+Math.round(Math.random() * 1000))} >Navigate to Superman</button>
           </div>
  };
  
  export default BatmanComp;