import { Component } from "react";

class App extends Component{
    render(){
        return <>
                <h1>Props</h1>
               </>
    }
}

export default App;