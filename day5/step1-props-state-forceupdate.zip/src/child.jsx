import { Component } from "react";
/* 
props are immutable
child component can not change it
*/
class ChildComp extends Component{
    power = 1;
    state = { 
        version : 1,
        firstname : "default first name",
        lastname : "default last name"
     };
    render(){
        return <>
                <h2>Child Component</h2>
                <h3>{ this.props.title }</h3>
                <button onClick={()=> {
                    // alert("you clicked the button");
                    console.log(this.props.title);
                    this.props.title = "Changed";
                    console.log(this.props.title);
                }} >Change Title</button>
                <hr />
                <h3>Power is : {this.power}</h3>
                <button onClick={()=> {
                    console.log("Before Change ",this.power);
                    this.power = 5;
                    console.log("After Change ",this.power);
                    this.forceUpdate();
                }} >Increase Power</button>
                <hr />
                <h3>Version is : {this.state.version}</h3>
                <button onClick={()=> {
                    this.setState({ version : this.state.version + 1 })
                }} >Increase Version</button>
                <hr />
                <h4>Name : { this.state.firstname+" "+this.state.lastname }</h4>
                <button onClick={ ()=> {
                    this.setState({
                        ...this.state, 
                        firstname : "Bruce"
                    })
                }}>Change First Name</button>
                <button onClick={ ()=> {
                    this.setState({
                        ...this.state,
                        lastname : "Wayne"
                    })
                }}>Change Last Name</button>
               </>
    }
}

export default ChildComp;