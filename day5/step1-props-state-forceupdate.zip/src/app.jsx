import { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    title = "This is App Title";
    render(){
        return <>
                <h1>Props</h1>
                <ChildComp title={this.title} />
               </>
    }
}

export default App;

/* 
vite
create react app
gatsby
remix
next
*/