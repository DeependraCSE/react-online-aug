import { Component } from "react";
class HeroComp extends Component{
    state = { };
    render(){
        return <>
                <h2>{this.props.title} Version : { this.props.version } | Release Year {this.props.releaseyear}</h2>
                <ol>
                    {this.props.list.map( (val, idx)=> <li key={idx}>{val}</li>)}
                </ol>
               </>
    }
}

export default HeroComp;