import { Component, createRef } from "react";
import HeroComp from "./hero";

class App extends Component{
    state = {
        avengers : [],
        justiceleague : [],
        indichereos : []
    }
    avengerip = createRef();
    justiceleagueip = createRef();
    indicheroip = createRef();
    render(){
        return <>
                <h1>Iteration</h1>
                <label htmlFor="avenger">Add Avenger</label>
                <input ref={this.avengerip} id="avenger" type="text" />
                <button onClick={() => {
                    this.setState({...this.state, avengers : [...this.state.avengers, this.avengerip.current.value]})
                }}>Add Avenger</button>
                <HeroComp list={this.state.avengers} releaseyear="2022" version={101} title="Avengers "/>
                <label htmlFor="justiceleague">Add Justice League Hero</label>
                <input ref={this.justiceleagueip} id="justiceleague" type="text" />
                <button>Add Justice League Hero</button>
                <HeroComp list={this.state.justiceleague} releaseyear="2023" version={102} title="Justice League "/>
                <label htmlFor="indichero">Add Indic Hero</label>
                <input ref={this.indicheroip} id="indichero" type="text" />
                <button>Add Indic Hero</button>
                <HeroComp list={this.state.indichereos} releaseyear="2024" version={103} title="Indic Hereos "/>
               </>
    }
}

export default App;