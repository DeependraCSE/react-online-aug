import { Component } from "react";
import ContainerComp from "./container";

class App extends Component{
    state = {
        title : "Hero List",
        version : 101,
        power : 5,
        releaseYear : 2024
    }
    render(){
        return <div style={ {border :' 1px solid black', padding : '10px', backgroundColor : 'silver'} }>
                <h1>Prop Types</h1>
                <ContainerComp title={this.state.title} version={this.state.version} power={this.state.power} releaseYear={this.state.releaseYear} />
                {/* <br />
                <ContainerComp {...this.state}/> */}
               </div>
    }
}

export default App;