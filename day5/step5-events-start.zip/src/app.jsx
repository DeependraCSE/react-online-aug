import { Component } from "react";

class App extends Component{
    state = {
        power : 1
    }
    render(){
        return <div>
                <h1>Events</h1>
                <h2>Power : { this.state.power }</h2>
                <button onClick={() => { this.setState({power : this.state.power + 1})}}>Increase Power</button>
                <br />
                <input onInput={(evt) => { this.setState({ power : Number(evt.target.value) })}} type="range" />
                <br />
                <input type="number" />
                <button>Increase Power to</button>
               </div>
    }
}

export default App;