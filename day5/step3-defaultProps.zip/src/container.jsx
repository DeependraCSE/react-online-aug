import { Component } from "react";
import HeroComp from "./hero";
class ContainerComp extends Component{
    state = { };
    render(){
        return <div style={ {border :' 1px solid black', padding : '10px', backgroundColor : 'grey'} }>
                <h3>Container</h3>
                <HeroComp title={this.props.title} version={this.props.version} power={this.props.power} releaseYear={this.props.releaseYear} />
                {/*  
               <br />
               <HeroComp {...this.props} /> 
               */}
               <br />
               <HeroComp  version={this.props.version} power={this.props.power} releaseYear={this.props.releaseYear} />
               <br />
               <HeroComp  power={this.props.power} releaseYear={this.props.releaseYear} />
               <br />
               <HeroComp  releaseYear={this.props.releaseYear} />
               <br />
               <HeroComp />
               </div>
    }
}

export default ContainerComp;