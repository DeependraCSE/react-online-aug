import { Component } from "react";
class HeroComp extends Component{
    state = { };
    // default Props
/*     static defaultProps = {
        title : "Default Title",
        power : 0,
        version : 0, 
        releaseYear : 2000
    } */
    render(){
        return <div style={ {border :' 1px solid black', padding : '10px', backgroundColor : 'darkslategrey'} }>
                <h4>Hero Component</h4>
                <h5>Title :  { this.props.title }</h5>
                <h5>Title :  { this.props.title }</h5>
                <h5>Title :  { this.props.title }</h5>
                <h5>Power :  { this.props.power }</h5>
                <h5>Power :  { this.props.power }</h5>
                <h5>Power :  { this.props.power }</h5>
                <h5>Version :  { this.props.version  }</h5>
                <h5>Version :  { this.props.version  }</h5>
                <h5>Power :  { this.props.power }</h5>
                <h5>Title :  { this.props.title }</h5>
                <h5>Version :  { this.props.version  }</h5>
                <h5>Power :  { this.props.power }</h5>
                <h5>Release Year :  { this.props.releaseYear }</h5>
               </div>
    }
}

HeroComp.defaultProps = {
    title : "Default Title",
    power : 0,
    version : 0, 
    releaseYear : 2000
};

export default HeroComp;