import React from 'react';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import updateMovies from './store/actions/updateMovies';
import fetchUsers from './store/actions/fetchUsers';

//Render Redux Cycle into App
function App() {
 let movies = useSelector(state => state.movies );
 let users = useSelector(state => state.users );
 let dispatch = useDispatch();
  return (
    <div className="App">
      <h3>REDUX MOVIELIST APP</h3>
      <br/>
      <span
      style={{color:'crimson'}}>YOUR CURRENT MOVIE IS: </span>{movies.name}
      <br/>
      <p><button onClick={() => dispatch(updateMovies)}>SELECT NEW MOVIE</button></p>
      <br/>
      {users.length === 0 ?
      <p>THERE ARE NO USERS</p> :
      users.map(user => <p key={user.id}>{user.name} - {user.email}</p>)}
      <br/>
      <button onClick={() => dispatch(fetchUsers)}>FETCH USERS</button>
    </div>
  );
};
export default App;

/* //Make State accessible to movies and users in App.
const MapStateToProps = (state) => {
  return {
    movies: state.movies,
    users: state.users
  };
};

// Setup Dispatch for our button events. 
const MapDispatchToProps = (dispatch) => {
  return {
    updateMovies: ()=> dispatch(updateMovies),
    fetchUsers: ()=> dispatch(fetchUsers)
  };
};

export default connect(MapStateToProps, MapDispatchToProps)(App); */
