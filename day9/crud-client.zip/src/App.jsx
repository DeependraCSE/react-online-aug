import { useEffect, useState } from "react";
import axios from "axios";

function App() {
let [heroes, setHeroes] = useState([]);
let [show, setShow] = useState(true);
let [hero, setHero] = useState({
                                title : '',
                                firstname : '',
                                lastname : '',
                                email : '',
                                city : ''
                              });
let [edithero, setEditHero] = useState({
                                _id : '',
                                title : '',
                                firstname : '',
                                lastname : '',
                                email : '',
                                city : ''
                              });
//----------------------------------
let reload = () => {
  axios.get("http://localhost:6060/data")
  .then(result => setHeroes(result.data))
  .catch(err => console.log("Error", err))
}                              
//----------------------------------
useEffect(()=>{
  reload();
},[]);
//----------------------------------
let changeHandler = (evt) => {
  setHero({...hero, [evt.target.id] : evt.target.value })
}
let editHandler = (evt) => {
  setEditHero({...edithero, [evt.target.id] : evt.target.value })
}
//----------------------------------
let addHero = () => {
  axios.post("http://localhost:6060/data", hero)
  .then(result => reload())
  .catch(err => console.log("Error", err))
}
//----------------------------------
let deleteHero = (hid) => {
  axios.delete("http://localhost:6060/delete/"+hid)
  .then(result => reload())
  .catch(err => console.log("Error", err))
}
//----------------------------------
let editHero = (hid) => {
  axios.get("http://localhost:6060/update/"+hid)
  .then(result => {
    setEditHero(result.data);
    setShow(false)
  })
  .catch(err => console.log("Error", err))
}
//----------------------------------
let updateHandler = () => {
  axios.post("http://localhost:6060/update/"+edithero._id, edithero)
  .then(result => {
    reload();
    setShow(true)
  })
  .catch(err => console.log("Error", err))
}
//----------------------------------
return <div className="container">
        <h1>CRUD APP</h1>
        <hr />
    {/* Add Form */} 
        { !show || <div>
          <h2>Add Hero</h2>
          <div className="mb-3">
            <label htmlFor="title" className="form-label">Hero Title</label>
            <input type="text" onInput={changeHandler} value={hero.title} className="form-control" id="title" />
          </div>
          <div className="mb-3">
            <label htmlFor="firstname" className="form-label">Hero FirstName</label>
            <input type="text" onInput={changeHandler} value={hero.firstname} className="form-control" id="firstname" />
          </div>
          <div className="mb-3">
            <label htmlFor="lastname" className="form-label">Hero LastName</label>
            <input type="text" onInput={changeHandler} value={hero.lastname} className="form-control" id="lastname" />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Hero eMail</label>
            <input type="text" onInput={changeHandler} value={hero.email} className="form-control" id="email" />
          </div>
          <div className="mb-3">
            <label htmlFor="city" className="form-label">Hero City</label>
            <input type="text" onInput={changeHandler} value={hero.city} className="form-control" id="city" />
          </div>
          <div className="mb-3">
            <button onClick={addHero} className="btn btn-primary">Add Hero</button>
          </div>
        </div>}
    {/* Edit Form */}
      { show || <div>
          <h2>Edit Hero</h2>
          <div className="mb-3">
            <label htmlFor="title" className="form-label">Edit Hero Title</label>
            <input type="text" onInput={editHandler} value={edithero.title} className="form-control" id="title" />
          </div>
          <div className="mb-3">
            <label htmlFor="firstname" className="form-label">Edit Hero FirstName</label>
            <input type="text" onInput={editHandler} value={edithero.firstname} className="form-control" id="firstname" />
          </div>
          <div className="mb-3">
            <label htmlFor="lastname" className="form-label">Edit Hero LastName</label>
            <input type="text" onInput={editHandler} value={edithero.lastname} className="form-control" id="lastname" />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Edit Hero eMail</label>
            <input type="text" onInput={editHandler} value={edithero.email} className="form-control" id="email" />
          </div>
          <div className="mb-3">
            <label htmlFor="city" className="form-label">Edit Hero City</label>
            <input type="text" onInput={editHandler} value={edithero.city} className="form-control" id="city" />
          </div>
          <div className="mb-3">
            <button onClick={updateHandler} className="btn btn-primary">Update Hero</button>
          </div>
        </div> }
        {/* <hr />
        <ul>
          <li>Title {hero.title}</li>
          <li>First Name {hero.firstname}</li>
          <li>Last Name {hero.lastname}</li>
          <li>City {hero.city}</li>
        </ul> */}
        {/* <ul>
          <li>Title {edithero.title}</li>
          <li>First Name {edithero.firstname}</li>
          <li>Last Name {edithero.lastname}</li>
          <li>eMail {edithero.email}</li>
          <li>City {edithero.city}</li>
        </ul> */}
        <hr />
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Sl#</th>
                <th>Title</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>eMail</th>
                <th>City</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              { heroes.map((val, idx) => <tr key={val._id}>
                                          <td>{ idx+1 }</td>
                                          <td>{ val.title }</td>
                                          <td>{ val.firstname }</td>
                                          <td>{ val.lastname }</td>
                                          <td>{ val.email }</td>
                                          <td>{ val.city }</td>
                                          <td> <button onClick={() => editHero(val._id) } className="btn btn-warning">Edit</button> </td>
                                          <td> <button onClick={()=> deleteHero(val._id)} className="btn btn-danger">Delete</button> </td>
                                        </tr>)}
            </tbody>
          </table>
       </div>
}

export default App
