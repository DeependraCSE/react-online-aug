const express = require("express");
const mongoose = require("mongoose");
const config = require("./config.json");
const cors = require("cors");

const app = express();

// Middlewares
//---------------------------
app.use(express.json());
app.use(cors());

// DB Connection
//---------------------------
// Model
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero",new Schema({
id :  ObjectId,
title :  String,
firstname :  String,
lastname :  String,
email :  String,
city :  String
}));

//---------------------------
let dbsrting = "mongodb+srv://{{uname}}:{{upass}}@cluster0.{{userstring}}.mongodb.net/{{dbname}}?retryWrites=true&w=majority&appName=Cluster0"
let url = dbsrting.replace("{{uname}}",config.dbusername).replace("{{upass}}",config.dbpassword).replace("{{userstring}}",config.userstring).replace("{{dbname}}",config.dbname);
mongoose.connect(url)
.then((res)=> console.log("DB Connected") )
.catch((err)=> console.log("Error ", err) )

// Routes
//---------------------------
// CREATE
app.post("/data",(req,res)=>{
     let hero = new Hero(req.body);
     hero.save()
     .then(dbres => res.status(200).send({message : dbres.title+ " was added"}))
     .catch(dberr => res.status(500).send({"Error" : dberr}))
})
// READ
app.get("/data",(req,res)=>{
 Hero.find()
    .then(dbres => res.send(dbres))
    .catch(error => console.log(error)) 
    // Hero.find().then(res => console.log(res)).catch(err => console.log("Error ", err))
})
// UPDATE
app.get("/update/:hid",(req, res)=>{
    Hero.findById(req.params.hid)
    .then(dbres => res.status(200).send(dbres))
    .catch(dberr => console.log(dberr))
})
app.post("/update/:hid",(req, res)=>{
    Hero.findByIdAndUpdate(req.params.hid,{ 
        title :  req.body.title,
        firstname :  req.body.firstname,
        lastname :  req.body.lastname,
        email :  req.body.email,
        city :  req.body.city 
        }).then(dbres => {
            console.log(dbres);
            res.send({message : "hero updated"})
        }).catch(dberr => console.log(dberr))
})
// DELETE
app.delete("/delete/:hid",(req,res)=>{
    Hero.findByIdAndDelete(req.params.hid)
    .then(dbres => {
        console.log(dbres);
        res.status(200).send({ message : "hero deleted" })
    })
    .catch(error => {
        console.log(error)
    })
})
// Web Server
//---------------------------
app.listen(6060,"localhost",function(error){
    if(error){ console.log("Error", error )}
    else{ console.log( "web server is now live on localhost:6060" )}
});