import React from 'react';
import { render, cleanup, fireEvent } from '@testing-library/react';
import PowerComp from './PowerComp'


describe("testing power", ()=>{
     afterEach(cleanup);
     it('increments power', () => {
        const { getByTestId } = render(<PowerComp />); 

        expect(getByTestId('powerlog')).toHaveTextContent('0')
        
        fireEvent.click(getByTestId('button-up'))
        fireEvent.click(getByTestId('button-up'))
    
        expect(getByTestId('powerlog')).toHaveTextContent('2')
      });
    
     it('decrements power', () => {
        const { getByTestId } = render(<PowerComp />); 
        
        fireEvent.click(getByTestId('button-down'))
        fireEvent.click(getByTestId('button-down'))
    
        expect(getByTestId('powerlog')).toHaveTextContent('-2')
      });
 })
