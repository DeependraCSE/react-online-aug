function App() {
  return <div>
          welcome to your life
         </div>;
}

export default App;
