import React from 'react'

const PowerComp = () => {
  const [power, setPower] = React.useState(0)
  
return <div>
          <h1 data-testid="powerlog">{ power }</h1>
          <button data-testid="button-up" onClick={() => setPower(power + 1)}> Increase </button>
          <button data-testid="button-down" onClick={() => setPower(power - 1)}> Decrease </button>
      </div>

  }
  
  export default PowerComp