import { render, screen } from '@testing-library/react';
import App from './App';

describe("checking the component", function(){
 test('should have welcome to your life', () => {
    render(<App />);
    const linkElement = screen.getByText(/welcome to your life/);
    expect(linkElement).toBeInTheDocument();
  });
})