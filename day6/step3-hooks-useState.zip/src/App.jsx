import { useRef } from "react";
import { useState, createRef } from "react"

let App = function(){ 
  // console.log(useState());// [state , function to manage the state]
  let [power, setPower] = useState(0);
  let [userinfo, setUserInfo] = useState({firstname : "Bruce", lastname: "Wayne" });
  let [avengers, setAvengers] = useState(["Ironman"])
  /*  
  setUserInfo({
    firstname : "default first name",
    lastname : "default last name"
  }); 
  */
  // let avengerIp = createRef();
  let avengerIp = useRef();
  return <>
           <div>
             <h1>API Calls</h1>
             <h2>Power : {power}</h2>
             <button onClick={()=> setPower(5)}>Set Power to 5</button>
             <button onClick={()=> setPower(power+1)}>Increase Power</button>
             <button onClick={()=> setPower(power-1)}>Decrease Power</button>
             <hr />
             <h3>Full Name : { userinfo.firstname +" "+ userinfo.lastname }</h3>
             <button onClick={() => setUserInfo({...userinfo, firstname : "your first name" })}>Set First name </button>
             <button onClick={() => setUserInfo({...userinfo, lastname : "your last name" })}>Set Last name </button>
             <hr />
             <label htmlFor="hero">New Avenger</label>
             <input id="hero" ref={avengerIp} type="text" />
             <button onClick={() => setAvengers([...avengers, avengerIp.current.value ])}>Add Avenger</button>
             <ol>
              { avengers.map( (val, idx) => <li key={idx}>{val}</li>)}
             </ol>
           </div>
         </>
}
export default App