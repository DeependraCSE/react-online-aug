import { Component } from 'react'

/* Lifecycle Events / Hooks / Methods
mounted
update
unmount
*/

class Child extends Component{
    snapshot = [];
    state = { 
        childpower : 0
    }
    // constructor
    constructor(){
        super();
        // this.state.childpower = 1;
        console.log("child's constructor was called");
    }

    // mount
    componentDidMount(){
        console.log("child component is mounted");
    }
    static getDerivedStateFromProps(props, state){
        // console.log(props, state);
        console.log("child's getDerivedStateFromProps is called");
        return {
            childpower : props.power * 2
        }
    }
    // update
    componentDidUpdate(){
        console.log("child component is updated", new Date().getMilliseconds());
        console.log(arguments[0], arguments[1], arguments[2]);
        // console.log("child component is updated", new Date().getMilliseconds());
        this.snapshot.push({...arguments[2], currentpower : arguments[0].power });
        console.log(this.snapshot);
    }
    shouldComponentUpdate(props, state){
        console.log("child's shouldComponentUpdate was called");
        console.log(arguments[0], arguments[1], arguments[2]);
        if(props.version < 10){
            return true
        }else{
            return false;
        }
    }
    getSnapshotBeforeUpdate(props,state){
        console.log(arguments.length);
        let date = new Date();
        return {
            time : date.getDate()+":"+date.getMinutes()+" : "+date.getSeconds(),
            previouspower : props.power,
            previouschildpower : state.childpower
        }
    }
    // unmounted
    componentWillUnmount(){
        console.log("child component is unmounted");
    }
    render(){
        console.log("child's render was called");
        return <>
                <div>
                    <h2>Child Component</h2>
                    <h2>Child Power : { this.state.childpower }</h2>
                    <h2>Power : { this.props.power }</h2>
                    <hr />
                    <h2>Version : { this.props.version }</h2>
                </div>
            </>
    }
}

export default Child
