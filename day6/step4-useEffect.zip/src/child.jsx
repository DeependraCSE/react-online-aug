import { useEffect } from "react"

let ChildComp = (props) => {
    // useEffect(()=> console.log("Child is mounted")); // mounted and updated
    useEffect(function(){
        console.log("Child is mounted")
    },[])
    useEffect(function(){
        console.log("Child is updated")
    },[props.power])
    useEffect(function(){
        return function(){
            console.log("Child is unmounted")
        }
    },[])
    return <div>
                <h3>Child Component</h3>
                <h3>Power : { props.power }</h3>
            </div>
};

export default ChildComp