import { useState } from "react"
import ChildComp from "./child"

let App = function(){ 
  let [show, setShow] = useState(true);
  let [power, setPower] = useState(0)
  return <>
           <div>
             <h1>API Calls</h1>
             <input onChange={()=> setShow(!show)} type="checkbox" />
             <br />
             <input type="range" onChange={(evt)=> setPower(Number(evt.target.value))} />
              { show ? <ChildComp power={power}/> : "child component is hidden"}
           </div>
         </>
}
export default App