import { Component } from 'react';
import axios from "axios";

class App extends Component{
  state = {
    result : {},
    users : []
  }
   // mount
  componentDidMount(){
    // will make an api call
    axios.get("https://reqres.in/api/users?page=1")
    .then(res => this.setState({ users : res.data.data }))
    .catch(err => console.log("Error ", err))
  };

  render(){
    return <>
              <div>
                <h1>API Calls</h1>
                {/* <p>{ JSON.stringify(this.state.result ) }</p> */}
                <ol>
                  { this.state.users.map( (val) => <li key={val.id}>{ val.first_name+" "+val.last_name }</li> ) }
                </ol> 
              </div>
           </>
  }
}

export default App
