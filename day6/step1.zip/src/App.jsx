import { Component } from 'react'
import Child from './child'

/* 
mounted / attached to parent
update
unmount
*/

class App extends Component{
  state = {
    show : true,
    power : 0,
    version : 0
  }
   // mount
  componentDidMount(){
    console.log("app component is mounted");
  }
  render(){
    return <>
              <div>
                <h1>Life Cycle Methods / Events</h1>
                <label>Increase / Decrease Power</label>
                <input type="range"  onInput={(evt) => this.setState({ power : Number(evt.target.value)})}/>
                <br />
                <label>Increase / Decrease Version</label>
                <input type="number"  onInput={(evt) => this.setState({ version : Number(evt.target.value)})}/>
                <br />
                <button onClick={()=> this.setState({ show : !this.state.show })}>Show / Hide</button>
                { this.state.show ? <Child version={this.state.version} power={this.state.power}/> : <h3>Child Componenet is hidden</h3>}
              </div>
           </>
  }
}

export default App
